﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdracht_3 {
    class Song {
        public int ranking;
        public string title;
        public string artist;
        public int yearOfPublication;
    }
}
